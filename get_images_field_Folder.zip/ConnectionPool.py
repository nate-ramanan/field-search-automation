from configparser import ConfigParser
from psycopg2.pool import SimpleConnectionPool

file = './config.ini'
config = ConfigParser()
config.read(file)

hostname = config['database']['hostname']
database = config['database']['database']
username = config['database']['username']
password = config['database']['password']
port_id = config['database']['port_id']

pool = SimpleConnectionPool(1, 20, user=username, password=password, host=hostname, port=port_id, database=database)
print("Connection pool created successfully")